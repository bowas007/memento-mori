# Memento Mori updater
# Checks the update feed and, when a newer version exists, downloads the update
# package, verifies its SHA-256 hash and installs it over the app directory.
# config.json is never touched by an update.
# Usage:
#   .\updater.ps1            check + install if newer (throttled to once a day)
#   .\updater.ps1 -Force     check + install, ignore the daily throttle
#
# Feed format (latest.json):
#   { "version": "1.1.0", "url": "https://.../MementoMori-1.1.0.zip",
#     "sha256": "<hex>", "notes": "..." }
# The feed URL below is the default; it can be overridden with an "updateFeed"
# field in config.json.

param([switch]$Force)

$ErrorActionPreference = 'Stop'
$DefaultFeedUrl = 'https://bowas007.github.io/memento-mori/updates/latest.json'

$root        = Split-Path -Parent $MyInvocation.MyCommand.Path
$versionFile = Join-Path $root 'version.txt'
$stampFile   = Join-Path $root 'last-update-check.txt'
$configPath  = Join-Path $root 'config.json'

# throttle: at most one check per day (the task also runs at every logon)
if (-not $Force -and (Test-Path $stampFile)) {
    try {
        $last = [datetime]::ParseExact((Get-Content $stampFile -Raw).Trim(), 'yyyy-MM-dd', [System.Globalization.CultureInfo]::InvariantCulture)
        if ((Get-Date).Date -le $last) { exit 0 }
    } catch {}
}
Set-Content -Path $stampFile -Value (Get-Date).ToString('yyyy-MM-dd') -Encoding ASCII

$current = [version](Get-Content $versionFile -Raw).Trim()

$feedUrl = $DefaultFeedUrl
try {
    $cfg = Get-Content $configPath -Raw | ConvertFrom-Json
    if ($cfg.PSObject.Properties['updateFeed'] -and $cfg.updateFeed) { $feedUrl = [string]$cfg.updateFeed }
} catch {}
if ($feedUrl -match 'REPLACE-ME') { exit 0 }  # feed not configured yet

[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
$feed = Invoke-RestMethod -Uri $feedUrl -TimeoutSec 30
$remote = [version]$feed.version
if ($remote -le $current) { exit 0 }

Write-Output "update: $current -> $remote"
$zipPath = Join-Path $env:TEMP ("MementoMori-update-" + $remote + ".zip")
Invoke-WebRequest -Uri $feed.url -OutFile $zipPath -TimeoutSec 300 -UseBasicParsing

$hash = (Get-FileHash -Path $zipPath -Algorithm SHA256).Hash
if ($hash -ne $feed.sha256.ToUpper()) {
    Remove-Item $zipPath -ErrorAction SilentlyContinue
    throw "hash mismatch: expected $($feed.sha256), got $hash"
}

$extractDir = Join-Path $env:TEMP ("MementoMori-update-" + $remote)
if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force }
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::ExtractToDirectory($zipPath, $extractDir)

# copy everything over the app dir, but never the user's config
Get-ChildItem -Path $extractDir -File -Recurse | ForEach-Object {
    $rel = $_.FullName.Substring($extractDir.Length).TrimStart('\')
    if ($rel -ieq 'config.json') { return }
    $dest = Join-Path $root $rel
    $destDir = Split-Path -Parent $dest
    if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }
    Copy-Item -Path $_.FullName -Destination $dest -Force
}

Remove-Item $zipPath, $extractDir -Recurse -Force -ErrorAction SilentlyContinue
Write-Output "updated to $remote"
