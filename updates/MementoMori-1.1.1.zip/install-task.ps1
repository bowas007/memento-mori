# Memento Mori scheduled task setup
# Registers (or removes) the per-user scheduled task that keeps the wallpaper
# current: every Monday 08:00 plus at logon, with StartWhenAvailable so a
# missed run happens as soon as the PC wakes up. Called by the installer.
# Usage:
#   .\install-task.ps1              register the task for this app directory
#   .\install-task.ps1 -Remove     remove the task

param([switch]$Remove)

$ErrorActionPreference = 'Stop'
$taskName = 'MementoMori'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

if ($Remove) {
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
    exit 0
}

$action = New-ScheduledTaskAction -Execute 'powershell.exe' `
    -Argument ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $root 'run-task.ps1') + '"')

$triggers = @(
    (New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday -At 08:00),
    (New-ScheduledTaskTrigger -AtLogOn -User ($env:USERDOMAIN + '\' + $env:USERNAME))
)

$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -DontStopIfGoingOnBatteries `
    -AllowStartIfOnBatteries -ExecutionTimeLimit (New-TimeSpan -Minutes 10)

Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $triggers -Settings $settings | Out-Null
Write-Output "scheduled task '$taskName' registered"
