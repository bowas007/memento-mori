# Memento Mori scheduled task entry point
# Runs at every Monday 08:00 and at logon: first a (throttled) update check,
# then a fresh wallpaper render. An update failure never blocks the render.

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

try {
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'updater.ps1') | Out-Null
} catch {}

& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'memento-mori.ps1')
