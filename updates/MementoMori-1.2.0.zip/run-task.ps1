# Memento Mori scheduled task entry point
# Runs daily at 08:00 and at logon: first a (throttled) update check, then a
# fresh wallpaper render. An update failure never blocks the render.
# Afterwards, if the app version changed since the task was registered (i.e. an
# update just landed), the task is re-registered so trigger changes take effect.

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

try {
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'updater.ps1') | Out-Null
} catch {}

& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'memento-mori.ps1')

try {
    $ver   = (Get-Content (Join-Path $root 'version.txt') -Raw -ErrorAction Stop).Trim()
    $stamp = Join-Path $root 'task-version.txt'
    $regd  = if (Test-Path $stamp) { (Get-Content $stamp -Raw).Trim() } else { '' }
    if ($regd -ne $ver) {
        & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'install-task.ps1') | Out-Null
    }
} catch {}
