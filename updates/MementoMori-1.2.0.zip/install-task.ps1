# Memento Mori scheduled task setup
# Registers (or removes) the per-user scheduled task that keeps the wallpaper
# current: daily at 08:00 (the quote changes every day) plus at logon, with
# StartWhenAvailable so a missed run happens as soon as the PC wakes up.
# Called by the installer, and by run-task.ps1 after an update.
# Usage:
#   .\install-task.ps1              register the task for this app directory
#   .\install-task.ps1 -Remove     remove the task

param([switch]$Remove)

$ErrorActionPreference = 'Stop'
$taskName = 'MementoMori'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

if ($Remove) {
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
    exit 0
}

$action = New-ScheduledTaskAction -Execute 'powershell.exe' `
    -Argument ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $root 'run-task.ps1') + '"')

$triggers = @(
    (New-ScheduledTaskTrigger -Daily -At 08:00),
    (New-ScheduledTaskTrigger -AtLogOn -User ($env:USERDOMAIN + '\' + $env:USERNAME))
)

$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -DontStopIfGoingOnBatteries `
    -AllowStartIfOnBatteries -ExecutionTimeLimit (New-TimeSpan -Minutes 10)

Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $triggers -Settings $settings | Out-Null
# remember which app version this task definition belongs to (see run-task.ps1)
try {
    $ver = (Get-Content (Join-Path $root 'version.txt') -Raw).Trim()
    Set-Content -Path (Join-Path $root 'task-version.txt') -Value $ver -Encoding ASCII
} catch {}
Write-Output "scheduled task '$taskName' registered"
