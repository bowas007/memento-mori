# Memento Mori wallpaper
# Rendert een levens-in-weken/maanden-raster (1 vakje = 1 week of 1 maand) plus een
# stoicijns citaat van de dag, en zet het als bureaubladachtergrond.
# Gebruik:
#   .\memento-mori.ps1                          rendert + zet als wallpaper
#   .\memento-mori.ps1 -Preview -OutFile x.png  alleen renderen, wallpaper blijft ongemoeid
#   .\memento-mori.ps1 -Theme light             thema-override (anders uit config)
#   .\memento-mori.ps1 -Today 2030-01-01        testdatum (klok vooruitzetten)
#   .\memento-mori.ps1 -ConfigFile pad.json     alternatieve config (voor de webinterface)

param(
    [switch]$Preview,
    [string]$OutFile = "",
    [string]$Theme = "",
    [string]$Today = "",
    [string]$ConfigFile = ""
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$cfgPath = if ($ConfigFile -ne "") { $ConfigFile } else { Join-Path $root 'config.json' }
$cfg = Get-Content $cfgPath -Raw | ConvertFrom-Json

# ontbrekende velden krijgen een standaardwaarde, zodat een oude config blijft werken
function Get-Opt($obj, [string]$name, $default) {
    if ($null -ne $obj -and $obj.PSObject.Properties[$name] -and $null -ne $obj.$name) { return $obj.$name }
    return $default
}

$inv   = [System.Globalization.CultureInfo]::InvariantCulture
$birth = [datetime]::ParseExact($cfg.birthdate, 'yyyy-MM-dd', $inv)
if ($Today -ne "") {
    $now = [datetime]::ParseExact($Today, 'yyyy-MM-dd', $inv)
} else {
    $now = (Get-Date).Date
}

$years    = [int](Get-Opt $cfg 'years' 80)
$unit     = [string](Get-Opt $cfg 'unit' 'weeks')       # weeks | months
$shape    = [string](Get-Opt $cfg 'shape' 'square')     # square | rounded | circle
$dotScale = [double](Get-Opt $cfg 'dotScale' 0.72)
if ($dotScale -lt 0.3) { $dotScale = 0.3 }
if ($dotScale -gt 0.95) { $dotScale = 0.95 }

$show          = Get-Opt $cfg 'show' $null
$showTitle     = [bool](Get-Opt $show 'title' $true)
$showCounter   = [bool](Get-Opt $show 'counter' $true)
$showPercent   = [bool](Get-Opt $show 'percent' $true)
$showYearLbls  = [bool](Get-Opt $show 'yearLabels' $true)
$showRowLbls   = [bool](Get-Opt $show 'rowLabels' $false)
$showQuote     = [bool](Get-Opt $show 'quote' $true)
$quotePos      = [string](Get-Opt $cfg 'quotePosition' 'top')   # top | bottom
if ($quotePos -ne 'bottom') { $quotePos = 'top' }

# --- quote of the day: one entry from quotes.json (or config 'quotesFile'), fixed for the whole day ---
$quote = $null
if ($showQuote) {
    $qPath = [string](Get-Opt $cfg 'quotesFile' '')
    if ($qPath -eq '') { $qPath = Join-Path $root 'quotes.json' }
    elseif (-not [System.IO.Path]::IsPathRooted($qPath)) { $qPath = Join-Path $root $qPath }
    try {
        # not via the pipeline: PS 5.1's ConvertFrom-Json emits a top-level array as ONE item
        $quotes = ConvertFrom-Json -InputObject (Get-Content $qPath -Raw -Encoding UTF8)
        $quotes = @($quotes)
        if ($quotes.Count -gt 0) {
            # day number times a large prime: walks through the whole list once before
            # repeating (as long as the list length is not a multiple of 7919), in a scrambled order
            $dayNo = [int](($now - [datetime]::new(2000, 1, 1)).TotalDays)
            $quote = $quotes[([long]$dayNo * 7919) % $quotes.Count]
        }
    } catch { $quote = $null }
}

$perYear    = if ($unit -eq 'months') { 12 } else { 52 }
$totalUnits = $years * $perYear

if ($unit -eq 'months') {
    $lived = ($now.Year - $birth.Year) * 12 + ($now.Month - $birth.Month)
    if ($now.Day -lt $birth.Day) { $lived-- }
} else {
    $lived = [int][math]::Floor(($now - $birth.Date).TotalDays / 7)
}
if ($lived -lt 0)           { $lived = 0 }
if ($lived -gt $totalUnits) { $lived = $totalUnits }

$themeName = [string](Get-Opt $cfg 'theme' 'light')
if ($Theme -ne "") { $themeName = $Theme }
$t = $cfg.themes.$themeName
if ($null -eq $t) { throw "Onbekend thema: $themeName" }

# --- schermresolutie (fallback 1920x1080) ---
$W = 0; $H = 0
try {
    $vc = Get-CimInstance Win32_VideoController |
        Where-Object { $_.CurrentHorizontalResolution -gt 0 } |
        Select-Object -First 1
    if ($vc) { $W = [int]$vc.CurrentHorizontalResolution; $H = [int]$vc.CurrentVerticalResolution }
} catch {}
if ($W -lt 800 -or $H -lt 600) { $W = 1920; $H = 1080 }

Add-Type -AssemblyName System.Drawing

function ColorOf([string]$hex) { [System.Drawing.ColorTranslator]::FromHtml($hex) }

$bmp = New-Object System.Drawing.Bitmap($W, $H)
$g   = [System.Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode     = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAlias

$bgBrush     = New-Object System.Drawing.SolidBrush (ColorOf $t.bg)
$filledBrush = New-Object System.Drawing.SolidBrush (ColorOf $t.filled)
$emptyBrush  = New-Object System.Drawing.SolidBrush (ColorOf $t.empty)
$accentBrush = New-Object System.Drawing.SolidBrush (ColorOf $t.accent)
$textBrush   = New-Object System.Drawing.SolidBrush (ColorOf $t.text)
$subBrush    = New-Object System.Drawing.SolidBrush (ColorOf $t.subtext)

$g.FillRectangle($bgBrush, 0, 0, $W, $H)

# --- rasterindeling: liggend, kolommen = jaren, rijen = weken/maanden binnen dat jaar ---
$quoteTop     = ($null -ne $quote -and $quotePos -eq 'top')
$quoteBottom  = ($null -ne $quote -and $quotePos -eq 'bottom')
$marginTop    = if ($showTitle -or $quoteTop) { [int]($H * 0.16) } else { [int]($H * 0.09) }
$marginBottom = if ($quoteBottom) { if ($showYearLbls) { [int]($H * 0.16) } else { [int]($H * 0.13) } }
                elseif ($showYearLbls) { [int]($H * 0.09) } else { [int]($H * 0.06) }
$gridAreaH    = $H - $marginTop - $marginBottom
$cell = [math]::Min([math]::Floor($gridAreaH / $perYear), [math]::Floor(($W * 0.88) / $years))
$cell = [int]$cell
$s    = [math]::Max(2, [int][math]::Floor($cell * $dotScale))
$gap  = $cell - $s

$gridW = $years * $cell - $gap
$gridH = $perYear * $cell - $gap
$x0 = [int](($W - $gridW) / 2)
$y0 = [int]($marginTop + ($gridAreaH - $gridH) / 2)

function Fill-Dot($brush, $x, $y, $s, $shape) {
    if ($shape -eq 'circle') {
        $script:g.FillEllipse($brush, $x, $y, $s, $s)
    } elseif ($shape -eq 'rounded' -and $s -ge 6) {
        $r = [math]::Max(2, [int]($s * 0.25)); $d = 2 * $r
        $p = New-Object System.Drawing.Drawing2D.GraphicsPath
        $p.AddArc($x, $y, $d, $d, 180, 90)
        $p.AddArc($x + $s - $d, $y, $d, $d, 270, 90)
        $p.AddArc($x + $s - $d, $y + $s - $d, $d, $d, 0, 90)
        $p.AddArc($x, $y + $s - $d, $d, $d, 90, 90)
        $p.CloseFigure()
        $script:g.FillPath($brush, $p)
        $p.Dispose()
    } else {
        $script:g.FillRectangle($brush, $x, $y, $s, $s)
    }
}

for ($i = 0; $i -lt $totalUnits; $i++) {
    $col = [math]::Floor($i / $perYear)   # jaar
    $row = $i % $perYear                  # week/maand binnen dat jaar
    $x = $x0 + $col * $cell
    $y = $y0 + $row * $cell
    if ($i -lt $lived) {
        Fill-Dot $filledBrush $x $y $s $shape
    } elseif ($i -eq $lived) {
        Fill-Dot $accentBrush $x $y $s $shape
    } else {
        Fill-Dot $emptyBrush $x $y $s $shape
    }
}

# --- lettertype: Rajdhani als die er is, anders Segoe UI ---
$fontName = 'Segoe UI'
try {
    $ff = New-Object System.Drawing.FontFamily('Rajdhani')
    $fontName = 'Rajdhani'
    $ff.Dispose()
} catch {}

$titleSize = [math]::Max(28, [int]($H * 0.050))
$smallSize = [math]::Max(12, [int]($H * 0.016))
$titleFont = New-Object System.Drawing.Font($fontName, $titleSize, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
$smallFont = New-Object System.Drawing.Font($fontName, $smallSize, [System.Drawing.FontStyle]::Regular, [System.Drawing.GraphicsUnit]::Pixel)

$titleY = [int]($marginTop * 0.24)

# titel linksboven op rasterbreedte
$titleText = [string](Get-Opt $cfg 'title' 'MEMENTO MORI')
if ($showTitle) {
    $g.DrawString($titleText, $titleFont, $textBrush, $x0 - 4, $titleY)
}

# teller rechtsboven, uitgelijnd op de rechterrand van het raster
# teksten en getalnotatie instelbaar: config 'locale' (bv. nl-NL) en 'counterWords'
$pct = [math]::Round(100 * $lived / $totalUnits)
if ($showCounter) {
    $localeName = [string](Get-Opt $cfg 'locale' 'en-US')
    try { $loc = [System.Globalization.CultureInfo]::GetCultureInfo($localeName) }
    catch { $loc = [System.Globalization.CultureInfo]::GetCultureInfo('en-US') }
    $words    = Get-Opt $cfg 'counterWords' $null
    $wordWeek  = [string](Get-Opt $words 'week' 'WEEK')
    $wordMonth = [string](Get-Opt $words 'month' 'MONTH')
    $wordOf    = [string](Get-Opt $words 'of' 'OF')
    $unitWord = if ($unit -eq 'months') { $wordMonth } else { $wordWeek }
    $counter = [string]::Format($loc, '{0} {1:N0} {2} {3:N0}', $unitWord, $lived, $wordOf, $totalUnits)
    if ($showPercent) { $counter = $counter + [string]::Format('   {0}%', $pct) }
    $cSize = $g.MeasureString($counter, $smallFont)
    $cy = if ($showTitle) { $titleY + $titleSize - $smallSize - 6 } else { $titleY }
    $g.DrawString($counter, $smallFont, $subBrush, $x0 + $gridW - $cSize.Width + 4, $cy)
}

# citaat van de dag (config 'quotePosition'):
#   top    = gecentreerd in de bovenbalk, tussen titel (links) en teller (rechts)
#   bottom = gecentreerd onder het raster (en onder de jaartallen), boven de taakbalk
if ($null -ne $quote) {
    $qText = [string]$quote.text
    $qBy   = [string]$quote.author
    if ($quote.PSObject.Properties['source'] -and $quote.source) { $qBy = $qBy + ', ' + [string]$quote.source }
    $pad   = [int]($W * 0.03)
    $left  = $x0; $right = $x0 + $gridW
    if ($quoteTop) {
        if ($showTitle)   { $left  = $x0 + $g.MeasureString($titleText, $titleFont).Width + $pad }
        if ($showCounter) { $right = $x0 + $gridW - $cSize.Width - $pad }
    } else {
        # onderaan: niet breder dan ~60% van het scherm, anders worden de regels te lang om te lezen
        $maxW = [int]($W * 0.60)
        if (($right - $left) -gt $maxW) { $left = [int](($W - $maxW) / 2); $right = $left + $maxW }
    }
    $boxW = [int]($right - $left)
    if ($boxW -ge $W * 0.25) {
        $fmt = New-Object System.Drawing.StringFormat
        $fmt.Alignment = [System.Drawing.StringAlignment]::Center
        $fmt.Trimming  = [System.Drawing.StringTrimming]::Word
        # begin ruim en verklein tot het citaat in twee regels past (of de ondergrens is bereikt)
        $qSize = [math]::Max(14, [int]($H * 0.021))
        $qMin  = [math]::Max(12, [int]($H * 0.015))
        $qFont = $null
        while ($true) {
            if ($qFont) { $qFont.Dispose() }
            $qFont = New-Object System.Drawing.Font($fontName, $qSize, [System.Drawing.FontStyle]::Italic, [System.Drawing.GraphicsUnit]::Pixel)
            $qMeasure = $g.MeasureString($qText, $qFont, $boxW, $fmt)
            if ($qMeasure.Height -le $qFont.GetHeight($g) * 2.2 -or $qSize -le $qMin) { break }
            $qSize--
        }
        # gebalanceerde regels: maak de tekstbreedte smaller zolang het aantal regels gelijk blijft,
        # zodat een tweede regel niet uit een enkel woord bestaat
        $lineH = $qFont.GetHeight($g)
        $lines = [math]::Round($qMeasure.Height / $lineH)
        $textW = $boxW
        if ($lines -ge 2) {
            # let op: niet '$w' noemen, PowerShell-variabelen zijn hoofdletterongevoelig ($W = schermbreedte)
            $tryW = $boxW
            while ($tryW -gt $boxW * 0.4) {
                $tryW = [int]($tryW * 0.96)
                $m = $g.MeasureString($qText, $qFont, $tryW, $fmt)
                if ([math]::Round($m.Height / $lineH) -gt $lines) { break }
                $textW = $tryW
            }
            $qMeasure = $g.MeasureString($qText, $qFont, $textW, $fmt)
        }
        $textX   = $left + ($boxW - $textW) / 2
        $bySize  = $g.MeasureString($qBy, $smallFont)
        $blockH  = $qMeasure.Height + $bySize.Height * 0.85
        $centerY = if ($quoteBottom) { $H - $H * 0.085 }            # onderrand ~5% boven de schermrand, vrij van de taakbalk
                   elseif ($showTitle) { $titleY + $titleSize * 0.5 } else { $marginTop * 0.45 }
        $top     = [int]($centerY - $blockH / 2)
        $quoteBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(215, (ColorOf $t.text)))
        $qRect  = [System.Drawing.RectangleF]::new([float]$textX, [float]$top, [float]$textW, [float]($qMeasure.Height + 2))
        $byRect = [System.Drawing.RectangleF]::new([float]$left, [float]($top + $qMeasure.Height - 2), [float]$boxW, [float]($bySize.Height + 2))
        $g.DrawString($qText, $qFont, $quoteBrush, $qRect, $fmt)
        $g.DrawString($qBy, $smallFont, $subBrush, $byRect, $fmt)
        $quoteBrush.Dispose(); $qFont.Dispose(); $fmt.Dispose()
    }
}

# jaartallen onder het raster, elke 10 jaar
if ($showYearLbls) {
    for ($yr = 10; $yr -le $years; $yr += 10) {
        $label = [string]$yr
        $lSize = $g.MeasureString($label, $smallFont)
        $lx = $x0 + ($yr * $cell) - $gap - ($lSize.Width / 2) + ($s / 2)
        $g.DrawString($label, $smallFont, $subBrush, $lx, $y0 + $gridH + [int]($H * 0.012))
    }
}

# week-/maandnummers links van het raster
if ($showRowLbls) {
    $step = if ($unit -eq 'months') { 3 } else { 10 }
    for ($n = $step; $n -le $perYear; $n += $step) {
        $label = [string]$n
        $lSize = $g.MeasureString($label, $smallFont)
        $lx = $x0 - $lSize.Width - [int]($W * 0.008)
        $ly = $y0 + (($n - 1) * $cell) + ($s / 2) - ($lSize.Height / 2)
        $g.DrawString($label, $smallFont, $subBrush, $lx, $ly)
    }
}

# --- opslaan ---
if ($OutFile -ne "") {
    $out = $OutFile
    if (-not [System.IO.Path]::IsPathRooted($out)) { $out = Join-Path (Get-Location) $out }
} else {
    $out = Join-Path $root 'wallpaper.png'
}
$bmp.Save($out, [System.Drawing.Imaging.ImageFormat]::Png)

$g.Dispose(); $bmp.Dispose()
$bgBrush.Dispose(); $filledBrush.Dispose(); $emptyBrush.Dispose(); $accentBrush.Dispose()
$textBrush.Dispose(); $subBrush.Dispose(); $titleFont.Dispose(); $smallFont.Dispose()

# --- als wallpaper instellen ---
if (-not $Preview) {
    Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name WallpaperStyle -Value '10'  # Fill
    Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name TileWallpaper  -Value '0'
    Add-Type @"
using System.Runtime.InteropServices;
public class BKWallpaper {
    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);
}
"@
    [void][BKWallpaper]::SystemParametersInfo(20, 0, $out, 3)  # SPI_SETDESKWALLPAPER, update ini + broadcast
}

Write-Output ("{0}x{1}, theme {2}, {3} {4} of {5} ({6}%), file: {7}" -f $W, $H, $themeName, $unit, $lived, $totalUnits, $pct, $out)
