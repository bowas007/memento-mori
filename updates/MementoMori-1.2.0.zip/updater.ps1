# Memento Mori updater
# Checks the update feed and, when a newer version exists, downloads the update
# package, verifies its SHA-256 hash AND an RSA signature made with the
# publisher's offline key, and only then installs it over the app directory.
# config.json is never touched by an update.
#
# Why the signature: the feed and the zip live on the same host. A hash from
# that host alone proves nothing if the host is compromised (an attacker swaps
# both). The signature is checked against the public key embedded below, which
# only changes through an update that was itself signed, so the download host
# cannot forge an update. Updates without a valid signature are refused.
# Usage:
#   .\updater.ps1            check + install if newer (throttled to once a day)
#   .\updater.ps1 -Force     check + install, ignore the daily throttle
#
# Feed format (latest.json):
#   { "version": "1.2.0", "url": "https://.../MementoMori-1.2.0.zip",
#     "sha256": "<hex>", "signature": "<base64>", "notes": "..." }
# signature = RSA PKCS#1 v1.5 / SHA-256 over the UTF-8 bytes of
#   "memento-mori-update|<version>|<sha256 upper hex>"
# (binding the version stops an old signed package being replayed as "newer").
# The feed URL below is the default; it can be overridden with an "updateFeed"
# field in config.json. Overriding the feed cannot bypass the signature check.

param([switch]$Force)

$ErrorActionPreference = 'Stop'
$DefaultFeedUrl = 'https://mementomoriwallpaper.com/updates/latest.json'

# publisher's update-signing public key (RSA 3072); the private key never
# leaves the publisher's machine
$UpdatePublicKey = '<RSAKeyValue><Modulus>wF4VZKoWidB0uSHMWUcJqBuHt/iBC9ihWLafKFKO+CuHwuaHIKu7MVFnWYt/iGtkHhT8qkkArGWUF0ll+83Ontdruj64PX2mSI3ljNC2UOvVrnw7AlLd7IdGmMV9XwB7TfkOIqj/HSCoy3MfW4Q5DwNGJIhUDzGX8O65jo5Xf0r2yqoWiA7XxKFa1h74voCanlSUAFBncml2u4e7RFkyWWKALrNix/U0Qcl+1fMPhkDXQgRj0PSbiUKEiOZQp5hmHfxFhutXYrpgrwqsu+ruVmo9hSlIo5eg2ExIdEhNcGYajidDR7OqsrGFdpuxAGVSK+zvbD3ahO0ISWjRqiu8aiwEqa15wwBiBYe9cx3y3CygAfZE8mZ1Okj6z9rx5dXcesidELURp6rm4W7wh2vT528d0YBALJ4wHUVLmAR0YVaXkSwM7XtkkJQoxK1dfJTisA876Dp+Zv1XDGhoCX0fAmStVslBjmsUWM5lLIHdpXvtNumiebVvAzrwtJ0ydSB5</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>'

function Test-UpdateSignature([string]$Version, [string]$Sha256, [string]$SignatureB64) {
    if (-not $SignatureB64) { return $false }
    try { $sig = [Convert]::FromBase64String($SignatureB64) } catch { return $false }
    $rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider
    try {
        $rsa.PersistKeyInCsp = $false
        $rsa.FromXmlString($UpdatePublicKey)
        $msg = [System.Text.Encoding]::UTF8.GetBytes("memento-mori-update|$Version|$($Sha256.ToUpper())")
        return $rsa.VerifyData($msg, 'SHA256', $sig)
    } catch { return $false } finally { $rsa.Dispose() }
}

$root        = Split-Path -Parent $MyInvocation.MyCommand.Path
$versionFile = Join-Path $root 'version.txt'
$stampFile   = Join-Path $root 'last-update-check.txt'
$configPath  = Join-Path $root 'config.json'

# throttle: at most one check per day (the task also runs at every logon)
if (-not $Force -and (Test-Path $stampFile)) {
    try {
        $last = [datetime]::ParseExact((Get-Content $stampFile -Raw).Trim(), 'yyyy-MM-dd', [System.Globalization.CultureInfo]::InvariantCulture)
        if ((Get-Date).Date -le $last) { exit 0 }
    } catch {}
}
Set-Content -Path $stampFile -Value (Get-Date).ToString('yyyy-MM-dd') -Encoding ASCII

$current = [version](Get-Content $versionFile -Raw).Trim()

$feedUrl = $DefaultFeedUrl
try {
    $cfg = Get-Content $configPath -Raw | ConvertFrom-Json
    if ($cfg.PSObject.Properties['updateFeed'] -and $cfg.updateFeed) { $feedUrl = [string]$cfg.updateFeed }
} catch {}
if ($feedUrl -match 'REPLACE-ME') { exit 0 }  # feed not configured yet

[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
$feed = Invoke-RestMethod -Uri $feedUrl -TimeoutSec 30
$remote = [version]$feed.version
if ($remote -le $current) { exit 0 }

Write-Output "update: $current -> $remote"
$zipPath = Join-Path $env:TEMP ("MementoMori-update-" + $remote + ".zip")
Invoke-WebRequest -Uri $feed.url -OutFile $zipPath -TimeoutSec 300 -UseBasicParsing

$hash = (Get-FileHash -Path $zipPath -Algorithm SHA256).Hash
if ($hash -ne $feed.sha256.ToUpper()) {
    Remove-Item $zipPath -ErrorAction SilentlyContinue
    throw "hash mismatch: expected $($feed.sha256), got $hash"
}

# authenticity: signature over the version string as published in the feed and
# the hash of the bytes we actually downloaded
$sigField = if ($feed.PSObject.Properties['signature']) { [string]$feed.signature } else { '' }
if (-not (Test-UpdateSignature ([string]$feed.version) $hash $sigField)) {
    Remove-Item $zipPath -ErrorAction SilentlyContinue
    throw "update $remote refused: missing or invalid signature"
}

$extractDir = Join-Path $env:TEMP ("MementoMori-update-" + $remote)
if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force }
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::ExtractToDirectory($zipPath, $extractDir)

# the package must contain the version it was signed as
$pkgVersionFile = Join-Path $extractDir 'version.txt'
$pkgVersion = if (Test-Path $pkgVersionFile) { (Get-Content $pkgVersionFile -Raw).Trim() } else { '' }
if ($pkgVersion -ne [string]$feed.version) {
    Remove-Item $zipPath, $extractDir -Recurse -Force -ErrorAction SilentlyContinue
    throw "update refused: package says version '$pkgVersion', feed says '$($feed.version)'"
}

# copy everything over the app dir, but never the user's config
Get-ChildItem -Path $extractDir -File -Recurse | ForEach-Object {
    $rel = $_.FullName.Substring($extractDir.Length).TrimStart('\')
    if ($rel -ieq 'config.json') { return }
    $dest = Join-Path $root $rel
    $destDir = Split-Path -Parent $dest
    if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }
    Copy-Item -Path $_.FullName -Destination $dest -Force
}

Remove-Item $zipPath, $extractDir -Recurse -Force -ErrorAction SilentlyContinue
Write-Output "updated to $remote"
