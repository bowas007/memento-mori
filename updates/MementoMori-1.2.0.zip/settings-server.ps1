# Memento Mori settings server
# Local, dependency-free settings UI. Serves webui.html, renders previews through
# the real renderer (memento-mori.ps1) and applies the wallpaper.
# Usage:
#   .\settings-server.ps1                 start server on http://localhost:4888
#   .\settings-server.ps1 -OpenBrowser    also open the browser
# The server exits by itself after 20 minutes without requests. The UI sends a
# keep-alive ping while it is open, so it never dies under an open page.
# If the port is already taken by a running instance, this script just opens the
# browser (if asked) and exits.

param(
    [int]$Port = 4888,
    [switch]$OpenBrowser,
    [int]$MaxIdleMinutes = 20
)

$ErrorActionPreference = 'Stop'
$root       = Split-Path -Parent $MyInvocation.MyCommand.Path
$renderer   = Join-Path $root 'memento-mori.ps1'
$configPath = Join-Path $root 'config.json'
$uiPath     = Join-Path $root 'webui.html'
$homeUrl    = "http://localhost:$Port/"

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($homeUrl)
try {
    $listener.Start()
} catch {
    # port in use: assume another instance is running
    if ($OpenBrowser) { Start-Process $homeUrl }
    exit 0
}
if ($OpenBrowser) { Start-Process $homeUrl }
Write-Output "Memento Mori settings: $homeUrl"

function Invoke-Renderer([string[]]$RendererArgs) {
    $psArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $renderer) + $RendererArgs
    $output = & powershell.exe $psArgs 2>&1
    if ($LASTEXITCODE -ne 0) { throw ("render failed: " + ($output -join ' ')) }
    return ($output -join ' ').Trim()
}

function Test-Config($cfg) {
    if ($null -eq $cfg) { throw 'no config' }
    if (-not ($cfg.birthdate -match '^\d{4}-\d{2}-\d{2}$')) { throw 'invalid birthdate' }
}

function Send-Bytes($ctx, [int]$code, [string]$type, [byte[]]$bytes) {
    $ctx.Response.StatusCode = $code
    $ctx.Response.ContentType = $type
    $ctx.Response.Headers.Add('Cache-Control', 'no-store')
    $ctx.Response.ContentLength64 = $bytes.Length
    $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $ctx.Response.OutputStream.Close()
}

function Send-Text($ctx, [int]$code, [string]$type, [string]$text) {
    Send-Bytes $ctx $code $type ([System.Text.Encoding]::UTF8.GetBytes($text))
}

function Write-Utf8([string]$path, [string]$text) {
    # UTF-8 without BOM (Set-Content -Encoding UTF8 writes a BOM on PS 5.1)
    [System.IO.File]::WriteAllText($path, $text, (New-Object System.Text.UTF8Encoding($false)))
}

function Read-Body($ctx) {
    $reader = New-Object System.IO.StreamReader($ctx.Request.InputStream, [System.Text.Encoding]::UTF8)
    try { return $reader.ReadToEnd() } finally { $reader.Dispose() }
}

function Handle-Request($ctx) {
    $method = $ctx.Request.HttpMethod
    $path   = $ctx.Request.Url.AbsolutePath

    if ($method -eq 'GET' -and ($path -eq '/' -or $path -eq '/index.html')) {
        Send-Bytes $ctx 200 'text/html; charset=utf-8' ([System.IO.File]::ReadAllBytes($uiPath))
        return
    }
    if ($method -eq 'GET' -and $path -eq '/config') {
        Send-Bytes $ctx 200 'application/json' ([System.IO.File]::ReadAllBytes($configPath))
        return
    }
    if ($method -eq 'GET' -and $path -eq '/ping') {
        Send-Text $ctx 200 'text/plain' 'ok'
        return
    }
    if ($method -eq 'POST' -and $path -eq '/preview') {
        $cfg = Read-Body $ctx | ConvertFrom-Json
        Test-Config $cfg
        $base    = Join-Path $env:TEMP ('mm-' + [guid]::NewGuid().ToString('N').Substring(0, 12))
        $cfgFile = $base + '.json'
        $pngFile = $base + '.png'
        try {
            Write-Utf8 $cfgFile (($cfg | ConvertTo-Json -Depth 10) + "`n")
            [void](Invoke-Renderer @('-Preview', '-ConfigFile', $cfgFile, '-OutFile', $pngFile))
            Send-Bytes $ctx 200 'image/png' ([System.IO.File]::ReadAllBytes($pngFile))
        } finally {
            Remove-Item -Path $cfgFile, $pngFile -ErrorAction SilentlyContinue
        }
        return
    }
    if ($method -eq 'POST' -and $path -eq '/apply') {
        $cfg = Read-Body $ctx | ConvertFrom-Json
        Test-Config $cfg
        $tmp = $configPath + '.tmp'
        Write-Utf8 $tmp (($cfg | ConvertTo-Json -Depth 10) + "`n")
        Move-Item -Path $tmp -Destination $configPath -Force
        $info = Invoke-Renderer @()
        Send-Text $ctx 200 'application/json' (@{ ok = $true; message = $info } | ConvertTo-Json -Compress)
        return
    }
    Send-Text $ctx 404 'text/plain; charset=utf-8' 'not found'
}

$lastActivity = Get-Date
try {
    while ($listener.IsListening) {
        $pending = $listener.GetContextAsync()
        while (-not $pending.Wait(2000)) {
            if (((Get-Date) - $lastActivity).TotalMinutes -ge $MaxIdleMinutes) {
                $listener.Stop()
                exit 0
            }
        }
        $ctx = $pending.Result
        $lastActivity = Get-Date
        try {
            Handle-Request $ctx
        } catch {
            $msg = @{ ok = $false; message = [string]$_.Exception.Message } | ConvertTo-Json -Compress
            try { Send-Text $ctx 500 'application/json' $msg } catch {}
        }
    }
} finally {
    if ($listener.IsListening) { $listener.Stop() }
    $listener.Close()
}
